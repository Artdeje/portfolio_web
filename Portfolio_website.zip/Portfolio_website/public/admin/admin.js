/* ─── admin.js — Full CRUD with Modal Forms ─── */

// Auth Guard
if (sessionStorage.getItem('and_admin_auth') !== 'true') {
    window.location.href = 'index.html';
}

// ─── API HELPER ───
async function apiFetch(endpoint, method = 'GET', body = null) {
    const options = { method, headers: { 'Content-Type': 'application/json' } };
    if (body) options.body = JSON.stringify(body);
    try {
        const res = await fetch('/api' + endpoint, options);
        if (!res.ok) throw new Error(res.statusText);
        return await res.json();
    } catch (err) {
        console.error('API Error:', err);
        showToast('Server error: ' + err.message, 'error');
        return null;
    }
}

// ─── SIDEBAR NAV ───
const navItems = document.querySelectorAll('.nav-item[data-panel]');
const panels   = document.querySelectorAll('.panel');
const topbarTitle  = document.getElementById('topbarTitle');
const sidebar      = document.getElementById('sidebar');
const overlay      = document.getElementById('sidebarOverlay');
const mobileToggle = document.getElementById('mobileToggle');

navItems.forEach(item => {
    item.addEventListener('click', () => {
        navItems.forEach(n => n.classList.remove('active'));
        item.classList.add('active');
        panels.forEach(p => p.classList.remove('active'));
        document.getElementById('panel-' + item.dataset.panel).classList.add('active');
        topbarTitle.textContent = item.textContent.trim();
        sidebar.classList.remove('open');
        overlay.classList.remove('show');
    });
});

mobileToggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlay.classList.toggle('show');
});
overlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
});
document.getElementById('logoutBtn').addEventListener('click', () => {
    sessionStorage.removeItem('and_admin_auth');
    window.location.href = 'index.html';
});

// ─── TOAST ───
function showToast(msg, type = 'success') {
    const existing = document.querySelector('.admin-toast');
    if (existing) existing.remove();
    const t = document.createElement('div');
    t.className = 'admin-toast';
    const colors = { success: '#10B981', error: '#EF4444', info: '#0EA5E9' };
    const icons  = { success: 'check-circle', error: 'times-circle', info: 'info-circle' };
    t.innerHTML = `<i class="fas fa-${icons[type]}"></i> ${msg}`;
    t.style.cssText = `position:fixed;bottom:2rem;right:2rem;background:${colors[type]};color:white;
        padding:.8rem 1.5rem;border-radius:10px;font-size:.9rem;font-weight:500;
        display:flex;align-items:center;gap:.5rem;box-shadow:0 10px 25px rgba(0,0,0,.3);
        animation:toastIn .3s ease;z-index:9999;`;
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 300); }, 2800);
}

// ─── MODAL ENGINE ───
let _modalConfirmOk = null;

function createModalHTML(id, title, bodyHTML, footerHTML) {
    const existing = document.getElementById(id);
    if (existing) existing.remove();
    const m = document.createElement('div');
    m.id = id;
    m.className = 'modal-backdrop';
    m.innerHTML = `
        <div class="modal-box">
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="modal-close" onclick="closeModal('${id}')">&times;</button>
            </div>
            <div class="modal-body">${bodyHTML}</div>
            <div class="modal-footer">${footerHTML}</div>
        </div>`;
    // Close on backdrop click
    m.addEventListener('click', e => { if (e.target === m) closeModal(id); });
    document.body.appendChild(m);
    // Animate open
    requestAnimationFrame(() => m.classList.add('open'));
}

function closeModal(id) {
    const m = document.getElementById(id);
    if (m) { m.classList.remove('open'); setTimeout(() => m.remove(), 250); }
}

function fieldHTML(label, id, type = 'text', value = '', placeholder = '', extra = '') {
    if (type === 'textarea') {
        return `<div class="field-group"><label>${label}</label>
            <textarea id="${id}" rows="3" placeholder="${placeholder}" ${extra}>${value}</textarea></div>`;
    }
    return `<div class="field-group"><label>${label}</label>
        <input type="${type}" id="${id}" value="${value.replace(/"/g, '&quot;')}" placeholder="${placeholder}" ${extra}></div>`;
}
function fieldRow(...fields) {
    return `<div class="field-row">${fields.join('')}</div>`;
}
function getVal(id) {
    const el = document.getElementById(id);
    return el ? el.value.trim() : '';
}

// ─── CONFIRM DIALOG ───
function confirmDialog(msg, onConfirm) {
    createModalHTML('modal-confirm', 'Confirm Action',
        `<p style="color:var(--dash-text2);font-size:.95rem;line-height:1.6;">${msg}</p>`,
        `<button class="btn-dash secondary" onclick="closeModal('modal-confirm')">Cancel</button>
         <button class="btn-dash danger" id="confirm-ok-btn">Yes, Delete</button>`
    );
    document.getElementById('confirm-ok-btn').addEventListener('click', () => {
        closeModal('modal-confirm');
        onConfirm();
    });
}

// ─── DASHBOARD STATS ───
async function renderStats() {
    const [data, feedback] = await Promise.all([apiFetch('/content'), apiFetch('/feedback')]);
    if (!data || !feedback) return;
    const certs    = data.certifications || [];
    const blogs    = data.blog || [];
    const projects = data.portfolio || [];
    const skills   = data.skills || [];
    const totalSkills = skills.reduce((sum, cat) => sum + (cat.items ? cat.items.length : 0), 0);

    document.getElementById('statsGrid').innerHTML = `
        <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-layer-group"></i></div>
            <div class="stat-num">${8 + projects.length + certs.length + totalSkills + blogs.length}</div><div class="stat-label">Total Items</div></div>
        <div class="stat-card"><div class="stat-icon green"><i class="fas fa-folder-open"></i></div>
            <div class="stat-num">${projects.length}</div><div class="stat-label">Projects</div></div>
        <div class="stat-card"><div class="stat-icon orange" style="background:rgba(249,115,22,0.15);color:#F97316;"><i class="fas fa-certificate"></i></div>
            <div class="stat-num">${certs.length}</div><div class="stat-label">Certifications</div></div>
        <div class="stat-card"><div class="stat-icon teal" style="background:rgba(20,184,166,0.15);color:#14B8A6;"><i class="fas fa-cogs"></i></div>
            <div class="stat-num">${totalSkills}</div><div class="stat-label">Skills</div></div>
        <div class="stat-card"><div class="stat-icon yellow"><i class="fas fa-pen-nib"></i></div>
            <div class="stat-num">${blogs.length}</div><div class="stat-label">Blog Posts</div></div>
        <div class="stat-card"><div class="stat-icon purple"><i class="fas fa-comments"></i></div>
            <div class="stat-num">${feedback.length}</div><div class="stat-label">Messages</div></div>`;
}

// ─── SIMPLE SECTION SAVE/LOAD ───
async function saveSection(section) {
    let body = {};
    if (section === 'site') {
        const currentData = await apiFetch('/content');
        const s = currentData.site || {};
        body = {
            seoTitle: s.seoTitle,
            seoDesc: s.seoDesc,
            seoKeywords: s.seoKeywords,
            seoFavicon: s.seoFavicon,
            alertEnabled: s.alertEnabled,
            alertText: s.alertText,
            logo: getVal('site-logo'),
            headerPic: getVal('site-headerPic'),
            showHeaderPic: document.getElementById('site-showHeaderPic').checked,
            footerDesc: getVal('site-footerDesc'), copyright: getVal('site-copyright'),
            navLabels: {
                home: getVal('nav-home'), about: getVal('nav-about'),
                certificates: getVal('nav-certificates'), skills: getVal('nav-skills'),
                experience: getVal('nav-experience'), blog: getVal('nav-blog'),
                portfolio: getVal('nav-portfolio'), contact: getVal('nav-contact')
            },
            socials: [
                { platform: 'linkedin',  url: getVal('soc-linkedin'),  icon: 'fab fa-linkedin' },
                { platform: 'github',    url: getVal('soc-github'),    icon: 'fab fa-github' },
                { platform: 'twitter',   url: getVal('soc-twitter'),   icon: 'fab fa-twitter' },
                { platform: 'instagram', url: getVal('soc-instagram'), icon: 'fab fa-instagram' }
            ]
        };
    } else if (section === 'about') {
        body = {
            p1: getVal('about-p1'), p2: getVal('about-p2'),
            stat1num: getVal('about-stat1num'), stat1label: getVal('about-stat1label'),
            stat2num: getVal('about-stat2num'), stat2label: getVal('about-stat2label'),
            stat3num: getVal('about-stat3num'), stat3label: getVal('about-stat3label'),
            stat4num: getVal('about-stat4num'), stat4label: getVal('about-stat4label')
        };
        await saveHeadings('about');
    } else if (section === 'contact') {
        body = {
            email: getVal('contact-email'), phone: getVal('contact-phone'),
            location: getVal('contact-location'), heading: getVal('contact-heading'),
            subtitle: getVal('contact-subtitle')
        };
        await saveHeadings('contact');
    }
    const res = await apiFetch(`/content/${section}`, 'PUT', body);
    if (res?.success) {
        showToast('Saved successfully!');
        if (section === 'site') setTimeout(() => location.reload(), 1200);
    }
}

async function saveHeadings(section) {
    const main = getVal(`head-${section}-main`);
    const accent = getVal(`head-${section}-accent`);
    const data = await apiFetch('/content');
    if (!data) return;
    if (!data.headings) data.headings = {};
    data.headings[section] = { main, accent };
    await apiFetch('/content/headings', 'PUT', data.headings);
}

async function loadSimpleFields() {
    const data = await apiFetch('/content');
    if (!data) return;

    const fill = (id, value) => { const el = document.getElementById(id); if (el) el.value = value || ''; };
    const check = (id, val) => { const el = document.getElementById(id); if (el) el.checked = !!val; };

    if (data.site) {
        const s = data.site;
        if (s.seoFavicon) {
            let linkIcon = document.querySelector('link[rel="icon"]');
            if (linkIcon) linkIcon.href = s.seoFavicon;
        }
        fill('site-logo', s.logo);
        fill('site-headerPic', s.headerPic); check('site-showHeaderPic', s.showHeaderPic);
        fill('site-footerDesc', s.footerDesc); fill('site-copyright', s.copyright);
        if (s.navLabels) Object.keys(s.navLabels).forEach(k => fill(`nav-${k}`, s.navLabels[k]));
        if (s.socials) s.socials.forEach(soc => fill(`soc-${soc.platform}`, soc.url));
    }
    if (data.headings) {
        Object.keys(data.headings).forEach(k => {
            fill(`head-${k}-main`, data.headings[k].main);
            fill(`head-${k}-accent`, data.headings[k].accent);
        });
    }
    if (data.about) {
        const a = data.about;
        fill('about-p1', a.p1); fill('about-p2', a.p2);
        ['1','2','3','4'].forEach(n => { fill(`about-stat${n}num`, a[`stat${n}num`]); fill(`about-stat${n}label`, a[`stat${n}label`]); });
    }
    if (data.contact) {
        const c = data.contact;
        fill('contact-email', c.email); fill('contact-phone', c.phone);
        fill('contact-location', c.location); fill('contact-heading', c.heading);
        fill('contact-subtitle', c.subtitle);
    }
}

// ─── CERTIFICATIONS CRUD ───
async function renderCerts() {
    const data = await apiFetch('/content');
    const certs = data?.certifications || [];
    const el = document.getElementById('cert-list');
    if (!certs.length) {
        el.innerHTML = `<div class="empty-state"><i class="fas fa-certificate"></i><p>No certifications yet. Click "Add New" to get started.</p></div>`;
        return;
    }
    el.innerHTML = certs.map((c, i) => `
        <div class="list-item">
            <div class="list-item-left">
                <div style="width:40px;height:40px;border-radius:10px;background:rgba(14,165,233,.15);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <i class="fas fa-certificate" style="color:#0EA5E9;"></i></div>
                <div class="list-item-info">
                    <h4>${c.title}</h4>
                    <p>${c.issuer || ''}${c.year ? ' · ' + c.year : ''}</p>
                </div>
            </div>
            <div class="btn-group">
                <button class="btn-dash ghost" onclick="editCertModal(${i})"><i class="fas fa-edit"></i> Edit</button>
                <button class="btn-dash danger" onclick="deleteCert(${i})"><i class="fas fa-trash"></i></button>
            </div>
        </div>`).join('');
}

function certModalHTML(c = {}) {
    return fieldHTML('Certificate Title', 'cert-title', 'text', c.title || '', 'e.g. Google UX Design')
         + fieldRow(
             fieldHTML('Issuer / Platform', 'cert-issuer', 'text', c.issuer || '', 'e.g. Coursera'),
             fieldHTML('Year', 'cert-year', 'text', c.year || '', '2024')
           )
         + fieldHTML('URL (optional)', 'cert-url', 'url', c.url || '', 'https://...');
}

function openAddCertModal() {
    createModalHTML('modal-cert', 'Add Certification', certModalHTML(),
        `<button class="btn-dash secondary" onclick="closeModal('modal-cert')">Cancel</button>
         <button class="btn-dash primary" onclick="submitCert()"><i class="fas fa-plus"></i> Add</button>`);
}

async function editCertModal(i) {
    const data = await apiFetch('/content');
    const c = data.certifications[i];
    createModalHTML('modal-cert', 'Edit Certification', certModalHTML(c),
        `<button class="btn-dash secondary" onclick="closeModal('modal-cert')">Cancel</button>
         <button class="btn-dash primary" onclick="updateCert(${i})"><i class="fas fa-save"></i> Save</button>`);
}

async function submitCert() {
    const title = getVal('cert-title');
    if (!title) { showToast('Title is required', 'error'); return; }
    const body = { title, issuer: getVal('cert-issuer'), year: getVal('cert-year'), url: getVal('cert-url') };
    const res = await apiFetch('/content/certifications', 'POST', body);
    if (res?.success) { closeModal('modal-cert'); renderCerts(); renderStats(); showToast('Certification added!'); }
}

async function updateCert(i) {
    const title = getVal('cert-title');
    if (!title) { showToast('Title is required', 'error'); return; }
    const body = { title, issuer: getVal('cert-issuer'), year: getVal('cert-year'), url: getVal('cert-url') };
    const res = await apiFetch(`/content/certifications/${i}`, 'PUT', body);
    if (res?.success) { closeModal('modal-cert'); renderCerts(); showToast('Certification updated!'); }
}

function deleteCert(i) {
    confirmDialog('Delete this certification? This cannot be undone.', async () => {
        const res = await apiFetch(`/content/certifications/${i}`, 'DELETE');
        if (res?.success) { renderCerts(); renderStats(); showToast('Certification removed!'); }
    });
}

// ─── SKILLS CRUD ───
async function renderSkills() {
    const data = await apiFetch('/content');
    const skills = data?.skills || [];
    const el = document.getElementById('skills-list');
    if (!skills.length) {
        el.innerHTML = `<div class="empty-state"><i class="fas fa-cogs"></i><p>No skill categories yet. Click "Add Category" to start.</p></div>`;
        return;
    }
    el.innerHTML = skills.map((cat, i) => `
        <div class="edit-card">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem;">
                <h3 style="margin:0;">${cat.category}</h3>
                <div class="btn-group">
                    <button class="btn-dash ghost" style="padding:.4rem .8rem;" onclick="editSkillCatModal(${i})"><i class="fas fa-edit"></i></button>
                    <button class="btn-dash danger" style="padding:.4rem .8rem;" onclick="deleteSkillCat(${i})"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            <div style="display:flex;flex-wrap:wrap;gap:.25rem;margin-bottom:1rem;">
                ${cat.items.map((s, j) => `<span class="skill-pill">${s}<i class="fas fa-times remove-pill" onclick="removeSkillItem(${i},${j})"></i></span>`).join('') || '<span style="color:var(--dash-text2);font-size:.85rem;">No skills yet.</span>'}
            </div>
            <button class="btn-dash ghost" style="font-size:.82rem;" onclick="addSkillItemModal(${i})"><i class="fas fa-plus"></i> Add Skill</button>
        </div>`).join('');
}

function openAddSkillCatModal() {
    createModalHTML('modal-skill-cat', 'Add Skill Category',
        fieldHTML('Category Name', 'skill-cat-name', 'text', '', 'e.g. Design Tools'),
        `<button class="btn-dash secondary" onclick="closeModal('modal-skill-cat')">Cancel</button>
         <button class="btn-dash primary" onclick="submitSkillCat()"><i class="fas fa-plus"></i> Add</button>`);
}

async function editSkillCatModal(i) {
    const data = await apiFetch('/content');
    const cat = data.skills[i];
    createModalHTML('modal-skill-cat', 'Edit Category Name',
        fieldHTML('Category Name', 'skill-cat-name', 'text', cat.category, ''),
        `<button class="btn-dash secondary" onclick="closeModal('modal-skill-cat')">Cancel</button>
         <button class="btn-dash primary" onclick="updateSkillCat(${i})"><i class="fas fa-save"></i> Save</button>`);
}

async function submitSkillCat() {
    const category = getVal('skill-cat-name');
    if (!category) { showToast('Category name is required', 'error'); return; }
    const res = await apiFetch('/content/skills', 'POST', { category, items: [] });
    if (res?.success) { closeModal('modal-skill-cat'); renderSkills(); showToast('Category added!'); }
}

async function updateSkillCat(i) {
    const category = getVal('skill-cat-name');
    if (!category) { showToast('Category name is required', 'error'); return; }
    const data = await apiFetch('/content');
    const cat = { ...data.skills[i], category };
    const res = await apiFetch(`/content/skills/${i}`, 'PUT', cat);
    if (res?.success) { closeModal('modal-skill-cat'); renderSkills(); showToast('Category updated!'); }
}

function addSkillItemModal(catIdx) {
    createModalHTML('modal-skill-item', 'Add Skill',
        fieldHTML('Skill Name', 'skill-item-name', 'text', '', 'e.g. React.js'),
        `<button class="btn-dash secondary" onclick="closeModal('modal-skill-item')">Cancel</button>
         <button class="btn-dash primary" onclick="submitSkillItem(${catIdx})"><i class="fas fa-plus"></i> Add</button>`);
}

async function submitSkillItem(catIdx) {
    const skill = getVal('skill-item-name');
    if (!skill) { showToast('Skill name is required', 'error'); return; }
    const data = await apiFetch('/content');
    const cat = data.skills[catIdx];
    cat.items.push(skill);
    const res = await apiFetch(`/content/skills/${catIdx}`, 'PUT', cat);
    if (res?.success) { closeModal('modal-skill-item'); renderSkills(); showToast('Skill added!'); }
}

async function removeSkillItem(catIdx, skillIdx) {
    const data = await apiFetch('/content');
    const cat = data.skills[catIdx];
    cat.items.splice(skillIdx, 1);
    const res = await apiFetch(`/content/skills/${catIdx}`, 'PUT', cat);
    if (res?.success) renderSkills();
}

function deleteSkillCat(i) {
    confirmDialog('Delete this entire skill category and all its skills?', async () => {
        const res = await apiFetch(`/content/skills/${i}`, 'DELETE');
        if (res?.success) { renderSkills(); showToast('Category removed!'); }
    });
}

// ─── EXPERIENCE CRUD ───
async function renderExp() {
    const data = await apiFetch('/content');
    const exps = data?.experience || [];
    const el = document.getElementById('exp-list');
    if (!exps.length) {
        el.innerHTML = `<div class="empty-state"><i class="fas fa-briefcase"></i><p>No experience entries yet. Click "Add Entry" to start.</p></div>`;
        return;
    }
    el.innerHTML = exps.map((e, i) => `
        <div class="list-item">
            <div class="list-item-left">
                <div style="width:40px;height:40px;border-radius:10px;background:rgba(245,158,11,.15);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <i class="fas fa-briefcase" style="color:#F59E0B;"></i></div>
                <div class="list-item-info">
                    <h4>${e.title} <span style="color:var(--dash-text2);font-weight:400;">@ ${e.company}</span></h4>
                    <p>${e.date}</p>
                </div>
            </div>
            <div class="btn-group">
                <button class="btn-dash ghost" onclick="editExpModal(${i})"><i class="fas fa-edit"></i> Edit</button>
                <button class="btn-dash danger" onclick="deleteExp(${i})"><i class="fas fa-trash"></i></button>
            </div>
        </div>`).join('');
}

function expModalHTML(e = {}) {
    return fieldRow(
               fieldHTML('Job Title', 'exp-title', 'text', e.title || '', 'e.g. Senior Developer'),
               fieldHTML('Company', 'exp-company', 'text', e.company || '', 'e.g. Google')
           )
         + fieldHTML('Date Range', 'exp-date', 'text', e.date || '', 'e.g. Jan 2023 – Present')
         + fieldHTML('Description / Responsibilities', 'exp-desc', 'textarea', e.desc || '', 'Describe your role...');
}

function openAddExpModal() {
    createModalHTML('modal-exp', 'Add Experience', expModalHTML(),
        `<button class="btn-dash secondary" onclick="closeModal('modal-exp')">Cancel</button>
         <button class="btn-dash primary" onclick="submitExp()"><i class="fas fa-plus"></i> Add</button>`);
}

async function editExpModal(i) {
    const data = await apiFetch('/content');
    const e = data.experience[i];
    createModalHTML('modal-exp', 'Edit Experience', expModalHTML(e),
        `<button class="btn-dash secondary" onclick="closeModal('modal-exp')">Cancel</button>
         <button class="btn-dash primary" onclick="updateExp(${i})"><i class="fas fa-save"></i> Save</button>`);
}

async function submitExp() {
    const title = getVal('exp-title');
    if (!title) { showToast('Job title is required', 'error'); return; }
    const body = { title, company: getVal('exp-company'), date: getVal('exp-date'), desc: getVal('exp-desc') };
    const res = await apiFetch('/content/experience', 'POST', body);
    if (res?.success) { closeModal('modal-exp'); renderExp(); renderStats(); showToast('Experience added!'); }
}

async function updateExp(i) {
    const title = getVal('exp-title');
    if (!title) { showToast('Job title is required', 'error'); return; }
    const body = { title, company: getVal('exp-company'), date: getVal('exp-date'), desc: getVal('exp-desc') };
    const res = await apiFetch(`/content/experience/${i}`, 'PUT', body);
    if (res?.success) { closeModal('modal-exp'); renderExp(); showToast('Experience updated!'); }
}

function deleteExp(i) {
    confirmDialog('Delete this experience entry?', async () => {
        const res = await apiFetch(`/content/experience/${i}`, 'DELETE');
        if (res?.success) { renderExp(); renderStats(); showToast('Entry removed!'); }
    });
}

// ─── BLOG CRUD ───
async function renderBlogs() {
    const data = await apiFetch('/content');
    const blogs = data?.blog || [];
    const el = document.getElementById('blog-list');
    if (!blogs.length) {
        el.innerHTML = `<div class="empty-state"><i class="fas fa-pen-nib"></i><p>No blog posts yet. Click "Add Post" to start.</p></div>`;
        return;
    }
    el.innerHTML = blogs.map((b, i) => `
        <div class="list-item">
            <div class="list-item-left">
                ${b.img ? `<img class="list-item-thumb" src="${b.img}" alt="${b.title}" onerror="this.style.display='none'">` : `<div class="list-item-thumb" style="display:flex;align-items:center;justify-content:center;"><i class="fas fa-blog" style="color:var(--dash-text2);"></i></div>`}
                <div class="list-item-info">
                    <h4>${b.title}</h4>
                    <p>${b.date || ''}${b.tag ? ' · <span style="color:var(--dash-accent);">' + b.tag + '</span>' : ''}</p>
                </div>
            </div>
            <div class="btn-group">
                <button class="btn-dash ghost" onclick="editBlogModal(${i})"><i class="fas fa-edit"></i> Edit</button>
                <button class="btn-dash danger" onclick="deleteBlog(${i})"><i class="fas fa-trash"></i></button>
            </div>
        </div>`).join('');
}

function blogModalHTML(b = {}) {
    return fieldHTML('Post Title', 'blog-title', 'text', b.title || '', 'e.g. My Design Journey')
         + fieldRow(
               fieldHTML('Date', 'blog-date', 'text', b.date || '', 'e.g. April 2025'),
               fieldHTML('Tag / Category', 'blog-tag', 'text', b.tag || '', 'e.g. Design')
           )
         + fieldHTML('Cover Image URL', 'blog-img', 'url', b.img || '', 'https://...')
         + fieldHTML('Excerpt / Summary', 'blog-excerpt', 'textarea', b.excerpt || '', 'Short summary of the post...');
}

function openAddBlogModal() {
    createModalHTML('modal-blog', 'Add Blog Post', blogModalHTML(),
        `<button class="btn-dash secondary" onclick="closeModal('modal-blog')">Cancel</button>
         <button class="btn-dash primary" onclick="submitBlog()"><i class="fas fa-plus"></i> Add Post</button>`);
}

async function editBlogModal(i) {
    const data = await apiFetch('/content');
    const b = data.blog[i];
    createModalHTML('modal-blog', 'Edit Blog Post', blogModalHTML(b),
        `<button class="btn-dash secondary" onclick="closeModal('modal-blog')">Cancel</button>
         <button class="btn-dash primary" onclick="updateBlog(${i})"><i class="fas fa-save"></i> Save</button>`);
}

async function submitBlog() {
    const title = getVal('blog-title');
    if (!title) { showToast('Title is required', 'error'); return; }
    const body = { title, date: getVal('blog-date'), tag: getVal('blog-tag'), img: getVal('blog-img'), excerpt: getVal('blog-excerpt') };
    const res = await apiFetch('/content/blog', 'POST', body);
    if (res?.success) { closeModal('modal-blog'); renderBlogs(); renderStats(); showToast('Blog post added!'); }
}

async function updateBlog(i) {
    const title = getVal('blog-title');
    if (!title) { showToast('Title is required', 'error'); return; }
    const body = { title, date: getVal('blog-date'), tag: getVal('blog-tag'), img: getVal('blog-img'), excerpt: getVal('blog-excerpt') };
    const res = await apiFetch(`/content/blog/${i}`, 'PUT', body);
    if (res?.success) { closeModal('modal-blog'); renderBlogs(); showToast('Blog post updated!'); }
}

function deleteBlog(i) {
    confirmDialog('Delete this blog post?', async () => {
        const res = await apiFetch(`/content/blog/${i}`, 'DELETE');
        if (res?.success) { renderBlogs(); renderStats(); showToast('Post removed!'); }
    });
}

// ─── PORTFOLIO CRUD ───
async function renderPortfolio() {
    const data = await apiFetch('/content');
    const projects = data?.portfolio || [];
    const el = document.getElementById('portfolio-list');
    if (!projects.length) {
        el.innerHTML = `<div class="empty-state"><i class="fas fa-folder-open"></i><p>No projects yet. Click "Add Project" to start.</p></div>`;
        return;
    }
    el.innerHTML = projects.map((p, i) => `
        <div class="list-item">
            <div class="list-item-left">
                ${p.img ? `<img class="list-item-thumb" src="${p.img}" alt="${p.title}" onerror="this.style.display='none'">` : `<div class="list-item-thumb" style="display:flex;align-items:center;justify-content:center;"><i class="fas fa-code" style="color:var(--dash-text2);"></i></div>`}
                <div class="list-item-info">
                    <h4>${p.title}</h4>
                    <p>${p.category || ''}${p.url ? ' · <a href="' + p.url + '" target="_blank" style="color:var(--dash-accent);font-size:.8rem;">View</a>' : ''}</p>
                </div>
            </div>
            <div class="btn-group">
                <button class="btn-dash ghost" onclick="editPortfolioModal(${i})"><i class="fas fa-edit"></i> Edit</button>
                <button class="btn-dash danger" onclick="deletePortfolio(${i})"><i class="fas fa-trash"></i></button>
            </div>
        </div>`).join('');
}

function portfolioModalHTML(p = {}) {
    return fieldHTML('Project Title', 'port-title', 'text', p.title || '', 'e.g. E-commerce Platform')
         + fieldRow(
               fieldHTML('Category', 'port-category', 'text', p.category || '', 'e.g. Web Development'),
               fieldHTML('Live URL', 'port-url', 'url', p.url || '', 'https://...')
           )
         + fieldHTML('Cover Image URL', 'port-img', 'url', p.img || '', 'https://...')
         + fieldHTML('Description', 'port-desc', 'textarea', p.desc || '', 'Describe the project...');
}

function openAddPortfolioModal() {
    createModalHTML('modal-port', 'Add Project', portfolioModalHTML(),
        `<button class="btn-dash secondary" onclick="closeModal('modal-port')">Cancel</button>
         <button class="btn-dash primary" onclick="submitPortfolio()"><i class="fas fa-plus"></i> Add Project</button>`);
}

async function editPortfolioModal(i) {
    const data = await apiFetch('/content');
    const p = data.portfolio[i];
    createModalHTML('modal-port', 'Edit Project', portfolioModalHTML(p),
        `<button class="btn-dash secondary" onclick="closeModal('modal-port')">Cancel</button>
         <button class="btn-dash primary" onclick="updatePortfolio(${i})"><i class="fas fa-save"></i> Save</button>`);
}

async function submitPortfolio() {
    const title = getVal('port-title');
    if (!title) { showToast('Title is required', 'error'); return; }
    const body = { title, category: getVal('port-category'), url: getVal('port-url'), img: getVal('port-img'), desc: getVal('port-desc') };
    const res = await apiFetch('/content/portfolio', 'POST', body);
    if (res?.success) { closeModal('modal-port'); renderPortfolio(); renderStats(); showToast('Project added!'); }
}

async function updatePortfolio(i) {
    const title = getVal('port-title');
    if (!title) { showToast('Title is required', 'error'); return; }
    const body = { title, category: getVal('port-category'), url: getVal('port-url'), img: getVal('port-img'), desc: getVal('port-desc') };
    const res = await apiFetch(`/content/portfolio/${i}`, 'PUT', body);
    if (res?.success) { closeModal('modal-port'); renderPortfolio(); showToast('Project updated!'); }
}

function deletePortfolio(i) {
    confirmDialog('Delete this project?', async () => {
        const res = await apiFetch(`/content/portfolio/${i}`, 'DELETE');
        if (res?.success) { renderPortfolio(); renderStats(); showToast('Project removed!'); }
    });
}

// ─── FEEDBACK ───
async function renderFeedback() {
    const feedback = await apiFetch('/feedback');
    const tbody = document.getElementById('feedbackBody');
    const noMsg  = document.getElementById('noFeedback');
    if (!feedback?.length) { tbody.innerHTML = ''; noMsg.style.display = 'block'; return; }
    noMsg.style.display = 'none';
    tbody.innerHTML = feedback.map((f, i) => `
        <tr>
            <td><strong>${f.name}</strong></td>
            <td><a href="mailto:${f.email}" style="color:var(--dash-accent);">${f.email}</a></td>
            <td style="max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${f.message}">${f.message}</td>
            <td style="white-space:nowrap;">${f.date}</td>
            <td>
                <div class="btn-group">
                    <button class="btn-dash ghost" style="padding:.3rem .6rem;font-size:.75rem;" onclick="viewFeedback(${i})"><i class="fas fa-eye"></i></button>
                    <button class="btn-dash danger" style="padding:.3rem .6rem;font-size:.75rem;" onclick="deleteFeedback(${i})"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        </tr>`).join('');
}

async function viewFeedback(i) {
    const feedback = await apiFetch('/feedback');
    const f = feedback[i];
    createModalHTML('modal-feedback-view', `Message from ${f.name}`,
        `<div class="field-group"><label>From</label><p style="color:var(--dash-text);padding:.5rem 0;">${f.name} &lt;${f.email}&gt;</p></div>
         <div class="field-group"><label>Date</label><p style="color:var(--dash-text);padding:.5rem 0;">${f.date}</p></div>
         <div class="field-group"><label>Message</label>
            <div style="background:var(--dash-surface2);padding:1rem;border-radius:8px;line-height:1.7;font-size:.9rem;">${f.message}</div>
         </div>`,
        `<a href="mailto:${f.email}" class="btn-dash primary"><i class="fas fa-reply"></i> Reply via Email</a>
         <button class="btn-dash secondary" onclick="closeModal('modal-feedback-view')">Close</button>`);
}

function deleteFeedback(i) {
    confirmDialog('Delete this message permanently?', async () => {
        const res = await apiFetch(`/feedback/${i}`, 'DELETE');
        if (res?.success) { renderFeedback(); renderStats(); showToast('Message deleted!'); }
    });
}

// ─── THEME ───
async function loadTheme() {
    const theme = await apiFetch('/theme');
    if (theme) {
        document.getElementById('theme-site').checked = (theme.site === 'dark');
        document.getElementById('theme-dash').checked = (theme.dash === 'dark');
        
        localStorage.setItem('and_portfolio_theme', theme.site === 'dark' ? 'dark' : 'default');
        localStorage.setItem('and_admin_theme', theme.dash === 'dark' ? 'dark' : 'light');

        if (theme.dash === 'light') {
            document.documentElement.setAttribute('data-dash-theme', 'light');
        } else {
            document.documentElement.removeAttribute('data-dash-theme');
        }
    }
}
async function saveTheme() {
    const siteDark = document.getElementById('theme-site').checked;
    const dashDark = document.getElementById('theme-dash').checked;
    
    // Instantly apply dashboard theme & update local storage for FOUC prevention
    localStorage.setItem('and_portfolio_theme', siteDark ? 'dark' : 'default');
    localStorage.setItem('and_admin_theme', dashDark ? 'dark' : 'light');

    if (!dashDark) {
        document.documentElement.setAttribute('data-dash-theme', 'light');
    } else {
        document.documentElement.removeAttribute('data-dash-theme');
    }
    
    const body = {
        site: siteDark ? 'dark' : 'default',
        dash: dashDark ? 'dark' : 'light'
    };
    const res = await apiFetch('/theme', 'PUT', body);
    if (res?.success) showToast('Theme saved!');
}

// ─── EXPOSE click-handlers used in onclick="" attributes in dashboard.html buttons ───
// (Certifications)
window.addCertItem           = openAddCertModal;
window.editCertItem          = editCertModal;
window.removeCertItem        = deleteCert;
// (Skills)
window.addSkillCategory      = openAddSkillCatModal;
window.editSkillCatModal     = editSkillCatModal;
window.deleteSkillCat        = deleteSkillCat;
window.addSkillItemModal     = addSkillItemModal;
window.removeSkillItem       = removeSkillItem;
// (Experience)
window.addExpItem            = openAddExpModal;
window.editExpItem           = editExpModal;
window.removeExpItem         = deleteExp;
// (Blog)
window.addBlogItem           = openAddBlogModal;
window.editBlogItem          = editBlogModal;
window.removeBlogItem        = deleteBlog;
// (Portfolio)
window.addPortfolioItem      = openAddPortfolioModal;
window.editPortfolioItem     = editPortfolioModal;
window.removePortfolioItem   = deletePortfolio;

// ─── SEO CRUD ───
async function renderSEO() {
    const data = await apiFetch('/content');
    if (!data || !data.site) return;
    const s = data.site;
    const el = document.getElementById('seo-display-area');
    if (el) {
        el.innerHTML = `
            <div style="margin-bottom:1rem;"><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Page Title (SEO)</label><div style="font-weight:600;">${s.seoTitle || 'Not set'}</div></div>
            <div style="margin-bottom:1rem;"><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Meta Description</label><div style="color:var(--dash-text);">${s.seoDesc || 'Not set'}</div></div>
            <div style="margin-bottom:1rem;"><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Meta Keywords</label><div style="color:var(--dash-text);">${s.seoKeywords || 'Not set'}</div></div>
            <div><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Favicon URL</label><div style="color:var(--dash-text);">${s.seoFavicon || 'Not set'}</div></div>
        `;
    }
}

async function openSEOModal() {
    const data = await apiFetch('/content');
    const s = data.site || {};
    createModalHTML('modal-seo', 'Edit SEO Configuration',
        fieldHTML('Page Title (SEO)', 'modal-seo-title', 'text', s.seoTitle || '', 'e.g. AND | Portfolio') +
        fieldHTML('Meta Description', 'modal-seo-desc', 'textarea', s.seoDesc || '', 'Short description of the site for search engines') +
        fieldHTML('Meta Keywords', 'modal-seo-keys', 'text', s.seoKeywords || '', 'e.g. portfolio, designer, developer') +
        fieldHTML('Favicon URL', 'modal-seo-favicon', 'text', s.seoFavicon || '', 'e.g. /assets/favicon.ico or https://...'),
        `<button class="btn-dash secondary" onclick="closeModal('modal-seo')">Cancel</button>
         <button class="btn-dash primary" onclick="updateSEO()"><i class="fas fa-save"></i> Update SEO</button>`
    );
}

async function updateSEO() {
    const data = await apiFetch('/content');
    if (!data.site) data.site = {};
    data.site.seoTitle = getVal('modal-seo-title');
    data.site.seoDesc = getVal('modal-seo-desc');
    data.site.seoKeywords = getVal('modal-seo-keys');
    data.site.seoFavicon = getVal('modal-seo-favicon');
    
    const res = await apiFetch(`/content/site`, 'PUT', data.site);
    if (res?.success) {
        closeModal('modal-seo');
        renderSEO();
        showToast('SEO updated successfully!');
    }
}

// ─── ALERT / MARQUEE CRUD ───
async function renderAlert() {
    const data = await apiFetch('/content');
    if (!data || !data.site) return;
    const s = data.site;
    const el = document.getElementById('alert-display-area');
    if (el) {
        el.innerHTML = `
            <div style="margin-bottom:1rem;"><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Status</label><div style="font-weight:600; color:${s.alertEnabled ? '#10B981' : '#EF4444'};">${s.alertEnabled ? 'ACTIVE' : 'INACTIVE'}</div></div>
            <div><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Message</label><div style="color:var(--dash-text);">${s.alertText || 'No message set'}</div></div>
        `;
    }
}

async function openAlertModal() {
    const data = await apiFetch('/content');
    const s = data.site || {};
    createModalHTML('modal-alert', 'Configure Emergency Announcement',
        `<div class="field-group theme-row" style="margin-bottom:1.5rem;background:var(--dash-surface2);padding:1rem;border-radius:8px;">
            <div class="theme-info"><h4>Enable Announcement Banner</h4></div>
            <label class="toggle-switch"><input type="checkbox" id="modal-alert-enabled" ${s.alertEnabled ? 'checked' : ''}><span class="toggle-slider"></span></label>
         </div>` +
        fieldHTML('Announcement Message', 'modal-alert-text', 'text', s.alertText || '', 'e.g. Website under maintenance...'),
        `<button class="btn-dash secondary" onclick="closeModal('modal-alert')">Cancel</button>
         <button class="btn-dash primary" onclick="updateAlert()"><i class="fas fa-save"></i> Save</button>`
    );
}

async function updateAlert() {
    const data = await apiFetch('/content');
    if (!data.site) data.site = {};
    data.site.alertEnabled = document.getElementById('modal-alert-enabled').checked;
    data.site.alertText = getVal('modal-alert-text');
    
    const res = await apiFetch(`/content/site`, 'PUT', data.site);
    if (res?.success) {
        closeModal('modal-alert');
        renderAlert();
        showToast('Announcement updated successfully!');
    }
}

// ─── HERO CRUD ───
async function renderHero() {
    const data = await apiFetch('/content');
    if (!data || !data.home) return;
    const h = data.home;
    const el = document.getElementById('hero-display-area');
    if (el) {
        el.innerHTML = `
            <div style="margin-bottom:1rem;"><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Full Name</label><div style="font-weight:600;">${h.name1 || ''} ${h.name2 || ''} <span style="color:var(--accent);">${h.name3 || ''}</span></div></div>
            <div style="margin-bottom:1rem;"><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Tagline</label><div style="color:var(--dash-text);">${h.tagline || 'Not set'}</div></div>
            <div style="margin-bottom:1rem;">
                <label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Call to Action</label>
                <div style="display:flex;gap:1.5rem;">
                    <div><span style="font-size:0.75rem;color:var(--dash-text2);">Text:</span> ${h.btntext || 'N/A'}</div>
                    <div><span style="font-size:0.75rem;color:var(--dash-text2);">Link:</span> ${h.btnlink || 'N/A'}</div>
                </div>
            </div>
            <div>
                <label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Avatar Graphic</label>
                ${h.avatar ? `<img src="${h.avatar}" style="width:50px;height:50px;object-fit:cover;border-radius:50%;border:2px solid var(--dash-border);">` : '<div style="color:var(--dash-text);">Not set</div>'}
            </div>
        `;
    }
}

async function openHeroModal() {
    const data = await apiFetch('/content');
    const h = data.home || {};
    createModalHTML('modal-hero', 'Edit Hero Settings',
        fieldRow(
            fieldHTML('First Name', 'modal-hero-n1', 'text', h.name1 || '', 'e.g. John'),
            fieldHTML('Middle Name', 'modal-hero-n2', 'text', h.name2 || '', 'e.g. Doe')
        ) +
        fieldHTML('Last Name (Gradient)', 'modal-hero-n3', 'text', h.name3 || '', 'e.g. Smith') +
        fieldHTML('Hero Tagline', 'modal-hero-tag', 'textarea', h.tagline || '', 'Your professional summary') +
        fieldRow(
            fieldHTML('Button Text', 'modal-hero-btn', 'text', h.btntext || '', 'e.g. View Portfolio'),
            fieldHTML('Button Link', 'modal-hero-link', 'text', h.btnlink || '', 'e.g. #portfolio')
        ) +
        fieldHTML('Avatar Image URL', 'modal-hero-avatar', 'text', h.avatar || '', 'e.g. assets/avatar.png'),
        `<button class="btn-dash secondary" onclick="closeModal('modal-hero')">Cancel</button>
         <button class="btn-dash primary" onclick="updateHero()"><i class="fas fa-save"></i> Save Hero Configuration</button>`
    );
}

async function updateHero() {
    const data = await apiFetch('/content');
    if (!data.home) data.home = {};
    data.home.name1 = getVal('modal-hero-n1');
    data.home.name2 = getVal('modal-hero-n2');
    data.home.name3 = getVal('modal-hero-n3');
    data.home.tagline = getVal('modal-hero-tag');
    data.home.btntext = getVal('modal-hero-btn');
    data.home.btnlink = getVal('modal-hero-link');
    data.home.avatar = getVal('modal-hero-avatar');
    
    const res = await apiFetch(`/content/home`, 'PUT', data.home);
    if (res?.success) {
        closeModal('modal-hero');
        renderHero();
        showToast('Hero section updated successfully!');
    }
}

// ─── BRANDING CRUD ───
async function renderBranding() {
    const data = await apiFetch('/content');
    if (!data || !data.site) return;
    const s = data.site;
    const el = document.getElementById('branding-display-area');
    if (el) {
        el.innerHTML = `
            <div style="margin-bottom:1rem;"><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Logo Text</label><div style="font-weight:600;">${s.logo || 'Not set'}</div></div>
            <div style="margin-bottom:1rem;">
                <label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Header Image</label>
                <div style="display:flex;align-items:center;gap:1rem;">
                    ${s.headerPic ? `<img src="${s.headerPic}" style="width:50px;height:50px;object-fit:cover;border-radius:8px;border:1px solid var(--dash-border);">` : '<div style="color:var(--dash-text);">No image</div>'}
                    <div style="font-size:0.85rem;color:var(--dash-text2);">${s.showHeaderPic ? '<span style="color:#10B981;"><i class="fas fa-eye"></i> Visible</span>' : '<span style="color:#EF4444;"><i class="fas fa-eye-slash"></i> Hidden</span>'}</div>
                </div>
            </div>
        `;
    }
}

async function openBrandingModal() {
    const data = await apiFetch('/content');
    const s = data.site || {};
    createModalHTML('modal-branding', 'Edit Global Branding',
        fieldHTML('Logo Text', 'modal-brand-logo', 'text', s.logo || '', 'e.g. ARTID') +
        fieldHTML('Header Picture URL', 'modal-brand-pic', 'text', s.headerPic || '', 'e.g. assets/profile.png') +
        `<div class="field-group theme-row" style="margin-top:1.5rem;background:var(--dash-surface2);padding:1rem;border-radius:8px;">
            <div class="theme-info"><h4>Show Header Picture</h4><p style="font-size:0.8rem;color:var(--dash-text2);">Toggle visibility on public site</p></div>
            <label class="toggle-switch"><input type="checkbox" id="modal-brand-show" ${s.showHeaderPic ? 'checked' : ''}><span class="toggle-slider"></span></label>
         </div>`,
        `<button class="btn-dash secondary" onclick="closeModal('modal-branding')">Cancel</button>
         <button class="btn-dash primary" onclick="updateBranding()"><i class="fas fa-save"></i> Save Branding</button>`
    );
}

async function updateBranding() {
    const data = await apiFetch('/content');
    if (!data.site) data.site = {};
    data.site.logo = getVal('modal-brand-logo');
    data.site.headerPic = getVal('modal-brand-pic');
    data.site.showHeaderPic = document.getElementById('modal-brand-show').checked;
    
    const res = await apiFetch(`/content/site`, 'PUT', data.site);
    if (res?.success) {
        closeModal('modal-branding');
        renderBranding();
        showToast('Branding updated successfully!');
    }
}

// ─── NAVIGATION CRUD ───
async function renderNav() {
    const data = await apiFetch('/content');
    if (!data || !data.site || !data.site.navLabels) return;
    const n = data.site.navLabels;
    const el = document.getElementById('nav-display-area');
    if (el) {
        el.innerHTML = Object.entries(n).map(([key, label]) => `
            <div style="background:var(--dash-surface);padding:0.8rem;border-radius:6px;border:1px solid var(--dash-border);">
                <label style="font-size:0.75rem;color:var(--dash-text2);display:block;text-transform:capitalize;margin-bottom:0.2rem;">${key}</label>
                <div style="font-weight:500;font-size:0.9rem;">${label}</div>
            </div>
        `).join('');
    }
}

async function openNavModal() {
    const data = await apiFetch('/content');
    const n = data.site?.navLabels || {};
    const keys = ['home', 'about', 'certificates', 'skills', 'experience', 'blog', 'portfolio', 'contact'];
    
    let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">';
    keys.forEach(k => {
        html += fieldHTML(k.charAt(0).toUpperCase() + k.slice(1), `modal-nav-${k}`, 'text', n[k] || '', k);
    });
    html += '</div>';

    createModalHTML('modal-nav', 'Edit Navigation Labels', html,
        `<button class="btn-dash secondary" onclick="closeModal('modal-nav')">Cancel</button>
         <button class="btn-dash primary" onclick="updateNav()"><i class="fas fa-save"></i> Save Labels</button>`
    );
}

async function updateNav() {
    const data = await apiFetch('/content');
    if (!data.site) data.site = {};
    if (!data.site.navLabels) data.site.navLabels = {};
    
    const keys = ['home', 'about', 'certificates', 'skills', 'experience', 'blog', 'portfolio', 'contact'];
    keys.forEach(k => {
        data.site.navLabels[k] = getVal(`modal-nav-${k}`);
    });
    
    const res = await apiFetch(`/content/site`, 'PUT', data.site);
    if (res?.success) {
        closeModal('modal-nav');
        renderNav();
        showToast('Navigation labels updated!');
    }
}

// ─── SOCIALS CRUD ───
async function renderSocials() {
    const data = await apiFetch('/content');
    if (!data || !data.site || !data.site.socials) return;
    const el = document.getElementById('socials-display-area');
    if (el) {
        el.innerHTML = `<div style="display:flex;flex-wrap:wrap;gap:1rem;">` + 
            data.site.socials.map(s => `
                <div style="display:flex;align-items:center;gap:0.5rem;background:var(--dash-surface);padding:0.6rem 1rem;border-radius:20px;border:1px solid var(--dash-border);">
                    <i class="${s.icon}" style="color:var(--dash-accent);"></i>
                    <span style="font-size:0.85rem;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${s.url || 'Not set'}</span>
                </div>
            `).join('') + `</div>`;
    }
}

async function openSocialsModal() {
    const data = await apiFetch('/content');
    const s = data.site?.socials || [];
    const getS = (p) => s.find(x => x.platform === p)?.url || '';

    createModalHTML('modal-socials', 'Edit Social Media Profiles',
        fieldHTML('LinkedIn URL', 'modal-soc-linkedin', 'url', getS('linkedin'), 'https://linkedin.com/in/...') +
        fieldHTML('GitHub URL', 'modal-soc-github', 'url', getS('github'), 'https://github.com/...') +
        fieldHTML('Twitter URL', 'modal-soc-twitter', 'url', getS('twitter'), 'https://twitter.com/...') +
        fieldHTML('Instagram URL', 'modal-soc-instagram', 'url', getS('instagram'), 'https://instagram.com/...'),
        `<button class="btn-dash secondary" onclick="closeModal('modal-socials')">Cancel</button>
         <button class="btn-dash primary" onclick="updateSocials()"><i class="fas fa-save"></i> Save Socials</button>`
    );
}

async function updateSocials() {
    const data = await apiFetch('/content');
    if (!data.site) data.site = {};
    data.site.socials = [
        { platform: 'linkedin',  url: getVal('modal-soc-linkedin'),  icon: 'fab fa-linkedin' },
        { platform: 'github',    url: getVal('modal-soc-github'),    icon: 'fab fa-github' },
        { platform: 'twitter',   url: getVal('modal-soc-twitter'),   icon: 'fab fa-twitter' },
        { platform: 'instagram', url: getVal('modal-soc-instagram'), icon: 'fab fa-instagram' }
    ];
    
    const res = await apiFetch(`/content/site`, 'PUT', data.site);
    if (res?.success) {
        closeModal('modal-socials');
        renderSocials();
        showToast('Social profiles updated!');
    }
}

// ─── FOOTER CRUD ───
async function renderFooter() {
    const data = await apiFetch('/content');
    if (!data || !data.site) return;
    const s = data.site;
    const el = document.getElementById('footer-display-area');
    if (el) {
        el.innerHTML = `
            <div style="margin-bottom:1rem;"><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Footer Description</label><div style="font-size:0.9rem;line-height:1.5;">${s.footerDesc || 'Not set'}</div></div>
            <div><label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.3rem;">Copyright Text</label><div style="font-weight:500;">${s.copyright || 'Not set'}</div></div>
        `;
    }
}

async function openFooterModal() {
    const data = await apiFetch('/content');
    const s = data.site || {};
    createModalHTML('modal-footer', 'Edit Footer Configuration',
        fieldHTML('Footer Description', 'modal-foot-desc', 'textarea', s.footerDesc || '', 'Short bio for footer') +
        fieldHTML('Copyright Text', 'modal-foot-copy', 'text', s.copyright || '', 'e.g. © 2026 Artdeje Studio'),
        `<button class="btn-dash secondary" onclick="closeModal('modal-footer')">Cancel</button>
         <button class="btn-dash primary" onclick="updateFooter()"><i class="fas fa-save"></i> Save Footer</button>`
    );
}

async function updateFooter() {
    const data = await apiFetch('/content');
    if (!data.site) data.site = {};
    data.site.footerDesc = getVal('modal-foot-desc');
    data.site.copyright = getVal('modal-foot-copy');
    
    const res = await apiFetch(`/content/site`, 'PUT', data.site);
    if (res?.success) {
        closeModal('modal-footer');
        renderFooter();
        showToast('Footer updated successfully!');
    }
}

// ─── ABOUT CRUD ───
async function renderAbout() {
    const data = await apiFetch('/content');
    if (!data || !data.about) return;
    const a = data.about;
    const el = document.getElementById('about-display-area');
    if (el) {
        el.innerHTML = `
            <div style="margin-bottom:1.5rem;">
                <label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.5rem;">Main Content (Paragraphs)</label>
                <div style="background:var(--dash-surface);padding:1rem;border-radius:8px;font-size:0.9rem;line-height:1.6;margin-bottom:0.5rem;">${a.p1}</div>
                <div style="background:var(--dash-surface);padding:1rem;border-radius:8px;font-size:0.9rem;line-height:1.6;">${a.p2}</div>
            </div>
            <label style="font-size:0.8rem;color:var(--dash-text2);display:block;margin-bottom:0.8rem;">Profile Statistics</label>
            <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(120px, 1fr));gap:1rem;">
                ${['1','2','3','4'].map(n => `
                    <div style="background:var(--dash-surface2);padding:0.8rem;border-radius:8px;text-align:center;border:1px solid var(--dash-border);">
                        <div style="font-size:1.2rem;font-weight:700;color:var(--dash-accent);">${a['stat'+n+'num']}</div>
                        <div style="font-size:0.75rem;color:var(--dash-text2);text-transform:uppercase;letter-spacing:1px;">${a['stat'+n+'label']}</div>
                    </div>
                `).join('')}
            </div>
        `;
    }
}

async function openAboutModal() {
    const data = await apiFetch('/content');
    const a = data.about || {};
    const h = data.headings?.about || {};

    createModalHTML('modal-about', 'Edit About Content & Stats',
        fieldRow(
            fieldHTML('Heading (Main)', 'modal-about-h1', 'text', h.main || '', 'About'),
            fieldHTML('Heading (Accent)', 'modal-about-h2', 'text', h.accent || '', 'Me')
        ) +
        fieldHTML('Paragraph 1', 'modal-about-p1', 'textarea', a.p1 || '', 'Introduction...') +
        fieldHTML('Paragraph 2', 'modal-about-p2', 'textarea', a.p2 || '', 'More details...') +
        '<label style="display:block;margin:1.5rem 0 0.5rem;font-weight:600;font-size:0.85rem;color:var(--dash-text2);">Statistics Grid</label>' +
        fieldRow(fieldHTML('Stat 1 Num', 'modal-about-s1n', 'text', a.stat1num || ''), fieldHTML('Stat 1 Label', 'modal-about-s1l', 'text', a.stat1label || '')) +
        fieldRow(fieldHTML('Stat 2 Num', 'modal-about-s2n', 'text', a.stat2num || ''), fieldHTML('Stat 2 Label', 'modal-about-s2l', 'text', a.stat2label || '')) +
        fieldRow(fieldHTML('Stat 3 Num', 'modal-about-s3n', 'text', a.stat3num || ''), fieldHTML('Stat 3 Label', 'modal-about-s3l', 'text', a.stat3label || '')) +
        fieldRow(fieldHTML('Stat 4 Num', 'modal-about-s4n', 'text', a.stat4num || ''), fieldHTML('Stat 4 Label', 'modal-about-s4l', 'text', a.stat4label || '')),
        `<button class="btn-dash secondary" onclick="closeModal('modal-about')">Cancel</button>
         <button class="btn-dash primary" onclick="updateAbout()"><i class="fas fa-save"></i> Save About Data</button>`
    );
}

async function updateAbout() {
    const data = await apiFetch('/content');
    if (!data.about) data.about = {};
    if (!data.headings) data.headings = {};
    
    data.headings.about = { main: getVal('modal-about-h1'), accent: getVal('modal-about-h2') };
    data.about = {
        p1: getVal('modal-about-p1'), p2: getVal('modal-about-p2'),
        stat1num: getVal('modal-about-s1n'), stat1label: getVal('modal-about-s1l'),
        stat2num: getVal('modal-about-s2n'), stat2label: getVal('modal-about-s2l'),
        stat3num: getVal('modal-about-s3n'), stat3label: getVal('modal-about-s3l'),
        stat4num: getVal('modal-about-s4n'), stat4label: getVal('modal-about-s4l')
    };
    
    await apiFetch('/content/headings', 'PUT', data.headings);
    const res = await apiFetch(`/content/about`, 'PUT', data.about);
    if (res?.success) {
        closeModal('modal-about');
        renderAbout();
        showToast('About section updated!');
    }
}

// ─── CONTACT CRUD ───
async function renderContact() {
    const data = await apiFetch('/content');
    if (!data || !data.contact) return;
    const c = data.contact;
    const el = document.getElementById('contact-display-area');
    if (el) {
        el.innerHTML = `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1rem;">
                <div><label style="font-size:0.75rem;color:var(--dash-text2);display:block;margin-bottom:0.2rem;">Email</label><div style="font-weight:500;">${c.email}</div></div>
                <div><label style="font-size:0.75rem;color:var(--dash-text2);display:block;margin-bottom:0.2rem;">Phone</label><div style="font-weight:500;">${c.phone}</div></div>
            </div>
            <div style="margin-bottom:1.5rem;"><label style="font-size:0.75rem;color:var(--dash-text2);display:block;margin-bottom:0.2rem;">Office Location</label><div style="font-weight:500;">${c.location}</div></div>
            <div style="border-top:1px solid var(--dash-border);padding-top:1rem;">
                <label style="font-size:0.75rem;color:var(--dash-text2);display:block;margin-bottom:0.5rem;">Public Call-to-Action</label>
                <div style="font-weight:600;font-size:1.1rem;margin-bottom:0.3rem;">${c.heading}</div>
                <div style="font-size:0.85rem;color:var(--dash-text2);">${c.subtitle}</div>
            </div>
        `;
    }
}

async function openContactModal() {
    const data = await apiFetch('/content');
    const c = data.contact || {};
    const h = data.headings?.contact || {};

    createModalHTML('modal-contact', 'Edit Contact Settings',
        fieldRow(
            fieldHTML('Section Header (Main)', 'modal-cont-h1', 'text', h.main || '', 'Get In'),
            fieldHTML('Section Header (Accent)', 'modal-cont-h2', 'text', h.accent || '', 'Touch')
        ) +
        fieldRow(
            fieldHTML('Email Address', 'modal-cont-email', 'email', c.email || ''),
            fieldHTML('Phone Number', 'modal-cont-phone', 'text', c.phone || '')
        ) +
        fieldHTML('Location', 'modal-cont-loc', 'text', c.location || '') +
        fieldHTML('CTA Heading', 'modal-cont-head', 'text', c.heading || '', 'Let\'s talk...') +
        fieldHTML('CTA Subtitle', 'modal-cont-sub', 'textarea', c.subtitle || '', 'I\'m always open...'),
        `<button class="btn-dash secondary" onclick="closeModal('modal-contact')">Cancel</button>
         <button class="btn-dash primary" onclick="updateContact()"><i class="fas fa-save"></i> Save Contact Data</button>`
    );
}

async function updateContact() {
    const data = await apiFetch('/content');
    if (!data.contact) data.contact = {};
    if (!data.headings) data.headings = {};
    
    data.headings.contact = { main: getVal('modal-cont-h1'), accent: getVal('modal-cont-h2') };
    data.contact = {
        email: getVal('modal-cont-email'), phone: getVal('modal-cont-phone'),
        location: getVal('modal-cont-loc'), heading: getVal('modal-cont-head'),
        subtitle: getVal('modal-cont-sub')
    };
    
    await apiFetch('/content/headings', 'PUT', data.headings);
    const res = await apiFetch(`/content/contact`, 'PUT', data.contact);
    if (res?.success) {
        closeModal('modal-contact');
        renderContact();
        showToast('Contact info updated!');
    }
}

// ─── INIT ───
async function init() {
    await loadSimpleFields();
    await renderStats();
    await Promise.all([
        renderCerts(), renderSkills(), renderExp(),
        renderBlogs(), renderPortfolio(), renderFeedback(), loadTheme(), renderSEO(), renderAlert(), renderHero(),
        renderBranding(), renderNav(), renderSocials(), renderFooter(), renderAbout(), renderContact()
    ]);
}

window.openAlertModal        = openAlertModal;
window.updateAlert           = updateAlert;
window.openSEOModal          = openSEOModal;
window.updateSEO             = updateSEO;
window.openHeroModal         = openHeroModal;
window.updateHero            = updateHero;

window.openBrandingModal     = openBrandingModal;
window.updateBranding        = updateBranding;
window.openNavModal          = openNavModal;
window.updateNav             = updateNav;
window.openSocialsModal      = openSocialsModal;
window.updateSocials         = updateSocials;
window.openFooterModal       = openFooterModal;
window.updateFooter          = updateFooter;
window.openAboutModal        = openAboutModal;
window.updateAbout           = updateAbout;
window.openContactModal      = openContactModal;
window.updateContact        = updateContact;

init();

