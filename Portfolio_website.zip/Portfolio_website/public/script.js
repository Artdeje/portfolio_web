// Function to load external HTML sections
async function loadSections() {
    const sections = [
        { id: 'about', file: 'about.html' },
        { id: 'certificates', file: 'certificates.html' },
        { id: 'skills', file: 'skills.html' },
        { id: 'experience', file: 'experience.html' },
        { id: 'blog', file: 'blog.html' },
        { id: 'portfolio', file: 'portfolio.html' },
        { id: 'contact', file: 'contact.html' }
    ];

    for (const section of sections) {
        try {
            const response = await fetch(section.file);
            if (!response.ok) throw new Error(`Failed to load ${section.file}`);
            const content = await response.text();
            document.getElementById(section.id).innerHTML = content;
        } catch (error) {
            console.error(error);
        }
    }

    // After all sections are loaded, initialize animations, apply dynamic content, and bind contact form
    initInteractions();
    applyDynamicContent();
    bindContactForm();
    applyWebsiteTheme();
}

function initInteractions() {
    // Mobile Menu Toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');

    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            mobileMenuBtn.querySelector('i').classList.toggle('fa-bars');
            mobileMenuBtn.querySelector('i').classList.toggle('fa-times');
        });
    }

    // Reveal Animations on Scroll
    const revealElements = document.querySelectorAll('.reveal');
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
            }
        });
    }, { threshold: 0.1 });

    revealElements.forEach(element => revealObserver.observe(element));

    // Navbar background change on scroll
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.style.padding = '1rem 0';
            navbar.style.background = 'rgba(17, 24, 39, 0.95)';
            navbar.style.backdropFilter = 'blur(10px)';
        } else {
            navbar.style.padding = '1.5rem 0';
            navbar.style.background = '#111827';
            navbar.style.backdropFilter = 'none';
        }
    });

    // Smooth scroll for nav links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
                // Close mobile menu if open
                if (navLinks.classList.contains('active')) {
                    navLinks.classList.remove('active');
                    mobileMenuBtn.querySelector('i').classList.add('fa-bars');
                    mobileMenuBtn.querySelector('i').classList.remove('fa-times');
                }
            }
        });
    });
}

// ─── DYNAMIC CONTENT FROM BACKEND API ───
async function applyDynamicContent() {
    let data;
    try { 
        const response = await fetch('/api/content');
        data = await response.json();
    } catch (error) { 
        console.error('Error fetching dynamic content:', error);
        return; 
    }

    // Site Settings & SEO
    if (data.site) {
        const s = data.site;
        
        // ─── EMERGENCY MARQUEE ───
        if (s.alertEnabled && s.alertText) {
            let alertDiv = document.getElementById('emergency-marquee');
            if (!alertDiv) {
                alertDiv = document.createElement('div');
                alertDiv.id = 'emergency-marquee';
                alertDiv.style.cssText = 'background: #EF4444; color: white; padding: 0.5rem 0; width: 100%; overflow: hidden; white-space: nowrap; font-weight: 600; text-align: center; font-size: 0.9rem; letter-spacing: 1px; flex-shrink: 0; position: fixed; top: 0; left: 0; z-index: 2000; box-shadow: 0 4px 12px rgba(239,68,68,0.3);';
                
                if (!document.getElementById('marquee-style')) {
                    const style = document.createElement('style');
                    style.id = 'marquee-style';
                    style.innerHTML = `@keyframes marquee-anim { 0% { transform: translateX(100vw); } 100% { transform: translateX(-100%); } }`;
                    document.head.appendChild(style);
                }
                
                document.body.prepend(alertDiv);
                
                // Push navbar down
                const navbar = document.getElementById('navbar');
                if (navbar) navbar.style.top = '34px';
            }
            alertDiv.innerHTML = `<span style="display: inline-block; animation: marquee-anim 15s linear infinite;">${s.alertText}</span>`;
        } else {
            const existingAlert = document.getElementById('emergency-marquee');
            if (existingAlert) existingAlert.remove();
            
            const navbar = document.getElementById('navbar');
            if (navbar) navbar.style.top = '0';
        }

        if (s.seoTitle) document.title = s.seoTitle;
        
        if (s.seoDesc) {
            let metaDesc = document.querySelector('meta[name="description"]');
            if (!metaDesc) {
                metaDesc = document.createElement('meta');
                metaDesc.name = "description";
                document.head.appendChild(metaDesc);
            }
            metaDesc.content = s.seoDesc;
        }

        if (s.seoKeywords) {
            let metaKeys = document.querySelector('meta[name="keywords"]');
            if (!metaKeys) {
                metaKeys = document.createElement('meta');
                metaKeys.name = "keywords";
                document.head.appendChild(metaKeys);
            }
            metaKeys.content = s.seoKeywords;
        }

        if (s.seoFavicon) {
            let linkIcon = document.querySelector('link[rel="icon"]');
            if (!linkIcon) {
                linkIcon = document.createElement('link');
                linkIcon.rel = "icon";
                document.head.appendChild(linkIcon);
            }
            linkIcon.href = s.seoFavicon;
        }
        
        const logo = document.querySelector('.logo a');
        if (logo && s.logo) logo.innerHTML = `<span class="text-gradient">${s.logo}</span>`;
        
        const navContainer = document.querySelector('.nav-container');
        if (navContainer) {
            if (s.showHeaderPic && s.headerPic) {
                let hPic = document.getElementById('headerProfilePic');
                if (!hPic) {
                    hPic = document.createElement('img');
                    hPic.id = 'headerProfilePic';
                    hPic.style.cssText = 'width:35px;height:35px;border-radius:50%;object-fit:cover;border:2px solid var(--accent);margin-left:1.5rem;';
                    // Insert after logo
                    const logoDiv = navContainer.querySelector('.logo');
                    if (logoDiv) logoDiv.after(hPic);
                }
                hPic.src = s.headerPic;
            } else if (document.getElementById('headerProfilePic')) {
                document.getElementById('headerProfilePic').remove();
            }
        }

        // Navigation Labels
        if (s.navLabels) {
            document.querySelectorAll('.nav-links a').forEach(link => {
                const href = link.getAttribute('href').replace('#', '');
                if (s.navLabels[href]) link.textContent = s.navLabels[href];
            });
            // Footer links
            document.querySelectorAll('.footer-nav a').forEach(link => {
                const href = link.getAttribute('href').replace('#', '');
                if (s.navLabels[href]) link.textContent = s.navLabels[href];
            });
        }

        // Social Links
        if (s.socials) {
            const socialGrids = document.querySelectorAll('.social-links');
            socialGrids.forEach(grid => {
                grid.innerHTML = s.socials.map(soc => `<a href="${soc.url}" target="_blank" title="${soc.platform}"><i class="${soc.icon}"></i></a>`).join('');
            });
        }

        const footDesc = document.querySelector('.footer-info p');
        if (footDesc && s.footerDesc) footDesc.textContent = s.footerDesc;
        const copyP = document.querySelector('.footer-bottom p');
        if (copyP && s.copyright) copyP.innerHTML = s.copyright;
    }

    // Section Headings
    if (data.headings) {
        Object.keys(data.headings).forEach(id => {
            const h = data.headings[id];
            const section = document.getElementById(id);
            if (section) {
                const title = section.querySelector('.page-title');
                if (title) {
                    title.innerHTML = `${h.main} <span class="text-gradient">${h.accent}</span>`;
                }
            }
        });
    }

    // Home section
    if (data.home) {
        const h = data.home;
        const heroH1 = document.querySelector('.hero-content h1');
        if (heroH1) {
            heroH1.innerHTML = `${h.name1 || ''} <br>${h.name2 || ''} <br><span class="text-gradient">${h.name3 || ''}</span>`;
        }
        const heroP = document.querySelector('.hero-content p');
        if (heroP && h.tagline) heroP.textContent = h.tagline;

        const heroBtn = document.querySelector('.hero-btns .btn');
        if (heroBtn) {
            if (h.btntext) heroBtn.textContent = h.btntext;
            if (h.btnlink) heroBtn.setAttribute('href', h.btnlink);
        }

        const avatarImg = document.querySelector('.avatar-circle img');
        if (avatarImg && h.avatar) {
            avatarImg.src = h.avatar;
            avatarImg.alt = `${h.name1 || ''} ${h.name2 || ''}`;
        }
    }

    // About section
    if (data.about) {
        const a = data.about;
        const aboutCard = document.querySelector('#about .card');
        if (aboutCard) {
            const paragraphs = aboutCard.querySelectorAll('p[style*="font-size: 1.1rem"]');
            if (paragraphs[0] && a.p1) paragraphs[0].textContent = a.p1;
            if (paragraphs[1] && a.p2) paragraphs[1].textContent = a.p2;

            const statNums = aboutCard.querySelectorAll('h2[style*="color: var(--accent)"]');
            const statLabels = aboutCard.querySelectorAll('p[style*="text-transform: uppercase"]');
            if (statNums[0] && a.stat1num) statNums[0].textContent = a.stat1num;
            if (statLabels[0] && a.stat1label) statLabels[0].textContent = a.stat1label;
            if (statNums[1] && a.stat2num) statNums[1].textContent = a.stat2num;
            if (statLabels[1] && a.stat2label) statLabels[1].textContent = a.stat2label;
            if (statNums[2] && a.stat3num) statNums[2].textContent = a.stat3num;
            if (statLabels[2] && a.stat3label) statLabels[2].textContent = a.stat3label;
            if (statNums[3] && a.stat4num) statNums[3].textContent = a.stat4num;
            if (statLabels[3] && a.stat4label) statLabels[3].textContent = a.stat4label;
        }
    }

    // Contact section
    if (data.contact) {
        const c = data.contact;
        const contactDiv = document.querySelector('#contact');
        if (contactDiv) {
            const heading = contactDiv.querySelector('h2');
            if (heading && c.heading) heading.textContent = c.heading;

            const subtitle = contactDiv.querySelector('div.reveal > p');
            if (subtitle && c.subtitle) subtitle.textContent = c.subtitle;

            const infoPs = contactDiv.querySelectorAll('.contact-item p[style*="font-weight: 600"]');
            if (infoPs[0] && c.email) infoPs[0].textContent = c.email;
            if (infoPs[1] && c.phone) infoPs[1].textContent = c.phone;
            if (infoPs[2] && c.location) infoPs[2].textContent = c.location;
        }
    }

    // Certifications — append custom items
    if (data.certifications && data.certifications.length > 0) {
        const certGrid = document.querySelector('#certificates .container > div[style*="grid"]');
        if (certGrid) {
            const icons = ['fa-certificate', 'fa-award', 'fa-medal', 'fa-star', 'fa-trophy'];
            data.certifications.forEach((cert, i) => {
                const div = document.createElement('div');
                div.className = 'card reveal';
                div.style.cssText = 'display:flex;align-items:start;gap:1.5rem;';
                div.innerHTML = `
                    <i class="fas ${icons[i % icons.length]}" style="font-size:2.5rem;color:var(--accent);"></i>
                    <div>
                        <h3 style="margin-bottom:0.5rem;">${cert.title}</h3>
                        <p style="color:var(--text-secondary);font-size:0.9rem;">${cert.issuer} | ${cert.year}</p>
                    </div>`;
                certGrid.appendChild(div);
            });
        }
    }

    // Experience — append custom items
    if (data.experience && data.experience.length > 0) {
        const expContainer = document.querySelector('#experience div[style*="max-width: 800px"]');
        if (expContainer) {
            data.experience.forEach(exp => {
                const div = document.createElement('div');
                div.className = 'timeline-item reveal';
                div.innerHTML = `
                    <div class="timeline-dot"></div>
                    <span class="timeline-date">${exp.date}</span>
                    <div class="timeline-content">
                        <h2 style="font-size:1.5rem;">${exp.title}</h2>
                        <h3 style="color:var(--text-secondary);font-weight:500;margin-bottom:1rem;">${exp.company}</h3>
                        <p style="color:var(--text-secondary);">${exp.desc}</p>
                    </div>`;
                expContainer.appendChild(div);
            });
        }
    }

    // Blog — append custom posts
    if (data.blog && data.blog.length > 0) {
        const blogGrid = document.querySelector('#blog .blog-grid');
        if (blogGrid) {
            data.blog.forEach(post => {
                const div = document.createElement('div');
                div.className = 'blog-card reveal';
                div.innerHTML = `
                    <div class="blog-img" style="background:${post.img ? `url('${post.img}')` : '#111827'};background-size:cover;"></div>
                    <div class="blog-content">
                        <span class="blog-date">${post.date}</span>
                        <h3 class="blog-title">${post.title}</h3>
                        <a href="#" class="blog-link">Read More <i class="fas fa-arrow-right"></i></a>
                    </div>`;
                blogGrid.appendChild(div);
            });
        }
    }

    // Portfolio — append custom projects
    if (data.portfolio && data.portfolio.length > 0) {
        const projGrid = document.querySelector('#portfolio .projects-grid');
        if (projGrid) {
            data.portfolio.forEach(proj => {
                const div = document.createElement('div');
                div.className = 'project-card reveal';
                div.innerHTML = `
                    <div class="project-img">
                        ${proj.img ? `<img src="${proj.img}" alt="${proj.title}">` : '<div style="width:100%;height:100%;background:var(--bg-dark);"></div>'}
                    </div>
                    <div class="project-info">
                        <span class="project-category">${proj.category}</span>
                        <h3>${proj.title}</h3>
                        <a href="#" class="btn btn-primary" style="padding:0.5rem 1.5rem;margin-top:1rem;">View Details</a>
                    </div>`;
                projGrid.appendChild(div);
            });
        }
    }

    // Skills — append custom categories
    if (data.skills && data.skills.length > 0) {
        const skillsGrid = document.querySelector('#skills .container > div[style*="grid"]');
        if (skillsGrid) {
            data.skills.forEach(cat => {
                const div = document.createElement('div');
                div.className = 'card reveal';
                div.innerHTML = `
                    <h3 style="margin-bottom:2rem;border-bottom:2px solid var(--accent);display:inline-block;">${cat.category}</h3>
                    <div style="display:flex;flex-wrap:wrap;gap:1rem;">
                        ${cat.items.map(s => `<span style="padding:0.6rem 1.2rem;background:#F3F4F6;border-radius:50px;font-size:0.9rem;font-weight:500;">${s}</span>`).join('')}
                    </div>`;
                skillsGrid.appendChild(div);
            });
        }
    }

    // Re-observe newly added .reveal elements
    const newReveals = document.querySelectorAll('.reveal:not(.active)');
    const obs = new IntersectionObserver((entries) => {
        entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('active'); });
    }, { threshold: 0.1 });
    newReveals.forEach(el => obs.observe(el));
}

// ─── CONTACT FORM SUBMISSION TO API ───
function bindContactForm() {
    const form = document.querySelector('#contact form.contact-form');
    if (!form) return;
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        const inputs = form.querySelectorAll('input, textarea');
        const name = inputs[0] ? inputs[0].value.trim() : '';
        const email = inputs[1] ? inputs[1].value.trim() : '';
        const message = inputs[2] ? inputs[2].value.trim() : '';
        if (!name || !email || !message) return;

        try {
            const response = await fetch('/api/feedback', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, message })
            });

            if (response.ok) {
                // Reset form and show confirmation
                form.reset();
                const btn = form.querySelector('button[type="submit"]');
                const origText = btn.textContent;
                btn.textContent = '✓ Message Sent!';
                btn.style.background = '#10B981';
                setTimeout(() => { btn.textContent = origText; btn.style.background = ''; }, 2500);
            }
        } catch (error) {
            console.error('Error submitting feedback:', error);
        }
    });
}

// ─── WEBSITE THEME FROM API ───
async function applyWebsiteTheme() {
    let theme;
    try { 
        const response = await fetch('/api/theme');
        theme = await response.json();
    } catch (error) { 
        console.error('Error fetching theme:', error);
        return; 
    }
    
    if (theme && theme.site === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
    } else {
        document.documentElement.removeAttribute('data-theme');
    }
}

// Initial load
document.addEventListener('DOMContentLoaded', loadSections);
